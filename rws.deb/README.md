# Debian .deb builder for Rust Web Server
To build rws as deb package simply clone repository and execute:
> dpkg-deb --build $HOME/rws-create-deb
